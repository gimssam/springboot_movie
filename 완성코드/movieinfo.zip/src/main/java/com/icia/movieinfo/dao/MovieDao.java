package com.icia.movieinfo.dao;

import com.icia.movieinfo.dto.MovieDto;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface MovieDao {
    List<MovieDto> getMovieList(Map<String, Integer> map);

    @Select("SELECT count(*) FROM movietbl")
    int cntMovie();

    void movieInsert(MovieDto movie);

    @Select("SELECT * FROM movietbl WHERE m_code=#{m_code}")
    MovieDto movieSelect(Integer m_code);

    void movieUpdate(MovieDto movie);

    @Select("SELECT p_sysname FROM movietbl WHERE m_code=#{m_code}")
    String getPoster(Integer m_code);

    @Delete("DELETE FROM movietbl WHERE m_code=#{m_code}")
    void movieDelete(Integer m_code);
}
